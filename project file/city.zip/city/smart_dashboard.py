import streamlit as st
from streamlit_option_menu import option_menu
from ui.summary_card import summary_card
from ui.feedback_form import render_feedback_form
from ui.chat_assistant import render_chat_assistant
from ui.eco_tips import render_eco_tips
from ui.policy_summarizer import render_policy_summarizer
from ui.report_generator import render_report_generator
from ui.document_uploader import render_document_uploader
from ui.policy_search import render_policy_search
from ui.kpi_forecasting import render_kpi_forecasting
from ui.anomaly_checker import render_anomaly_checker

# Colorful, modern CSS
st.markdown("""
<style>
body, .stApp {
    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%) !important;
    color: #222 !important;
    font-family: 'Inter', 'Segoe UI', Arial, sans-serif;
}
.main-header {
    padding: 1.5rem 0 1rem 0;
    text-align: center;
    font-size: 2.2rem;
    font-weight: 700;
    color: #fff;
    letter-spacing: 0.01em;
    background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
    border-radius: 12px;
    margin-bottom: 2rem;
    box-shadow: 0 4px 16px rgba(102,126,234,0.08);
}
.metric-card {
    background: linear-gradient(120deg, #8afff3 0%, #6a82fb 100%);
    padding: 1.2rem 1rem;
    border-radius: 10px;
    border: none;
    color: #222;
    margin-bottom: 1rem;
    box-shadow: 0 2px 8px rgba(106,130,251,0.08);
}
.metric-card h4 {
    color: #2c3e50;
    margin-bottom: 0.5rem;
    font-size: 1.1rem;
    font-weight: 600;
}
.chart-container {
    background: linear-gradient(120deg, #f093fb 0%, #f5576c 100%);
    padding: 1rem;
    border-radius: 10px;
    border: none;
    margin: 1rem 0;
    box-shadow: 0 2px 8px rgba(240,147,251,0.08);
}
.stMarkdown, .stText, .dashboard-text {
    color: #2c3e50 !important;
    font-weight: 400;
}
.stButton>button {
    background: linear-gradient(90deg, #43e97b 0%, #38f9d7 100%);
    color: #222;
    border-radius: 6px;
    border: none;
    font-weight: 500;
}
.stButton>button:hover {
    background: linear-gradient(90deg, #38f9d7 0%, #43e97b 100%);
}
.stSidebar {
    background: linear-gradient(135deg, #667eea 0%, #c3cfe2 100%) !important;
}
</style>
""", unsafe_allow_html=True)

def main():
    # Sidebar navigation (colorful)
    with st.sidebar:
        st.markdown("<h2 style='margin-bottom:0.5rem; color:#fff; background:linear-gradient(90deg,#667eea,#764ba2); padding:0.5rem 1rem; border-radius:8px;'>🏙️ Smart City</h2>", unsafe_allow_html=True)
        selected = option_menu(
            menu_title=None,
            options=[
                "Dashboard", "Policy Search", "Chat", "Eco Tips", 
                "KPI Forecasting", "Anomaly Checker", "Report Generator", "Feedback"
            ],
            icons=[
                'house', 'search', 'chat-dots', 'lightbulb', 
                'graph-up-arrow', 'exclamation-triangle', 'journal-richtext', 'chat-left-text'
            ],
            menu_icon="cast",
            default_index=0,
            styles={
                "container": {"padding": "0!important", "background-color": "#fafbfc"},
                "icon": {"color": "#764ba2", "font-size": "18px"}, 
                "nav-link": {"font-size": "15px", "text-align": "left", "margin":"0px", "--hover-color": "#e0e0e0", "color": "#222"},
                "nav-link-selected": {"background-color": "#667eea", "color": "#fff"},
            }
        )
        st.markdown("---")

    # Main content area
    st.markdown('<div class="main-header">🏙️ Smart City Dashboard</div>', unsafe_allow_html=True)

    if selected == "Dashboard":
        # Colorful dashboard: Custom KPI cards and charts
        kpi_col1, kpi_col2, kpi_col3, spacer = st.columns([1.2, 1.2, 1.2, 0.4])
        with kpi_col1:
            st.markdown('''
                <div style="background: linear-gradient(120deg, #43e97b 0%, #38f9d7 100%); border-radius: 12px; padding: 1.2rem 1rem; color: #222; box-shadow: 0 2px 8px rgba(67,233,123,0.08);">
                    <div style="font-size: 1.1rem; font-weight: 600; color: #1b5e20;">⚡ Energy Consumption</div>
                    <div style="font-size: 2.1rem; font-weight: 700; margin: 0.2rem 0;">1.2 MWh</div>
                    <div style="font-size: 1rem; color: #388e3c;">▲ 2% from last week</div>
                </div>
            ''', unsafe_allow_html=True)
        with kpi_col2:
            st.markdown('''
                <div style="background: linear-gradient(120deg, #f7971e 0%, #ffd200 100%); border-radius: 12px; padding: 1.2rem 1rem; color: #222; box-shadow: 0 2px 8px rgba(247,151,30,0.08);">
                    <div style="font-size: 1.1rem; font-weight: 600; color: #b26a00;">💧 Water Usage</div>
                    <div style="font-size: 2.1rem; font-weight: 700; margin: 0.2rem 0;">8M Gallons</div>
                    <div style="font-size: 1rem; color: #b26a00;">▼ 5% from last week</div>
                </div>
            ''', unsafe_allow_html=True)
        with kpi_col3:
            st.markdown('''
                <div style="background: linear-gradient(120deg, #f093fb 0%, #f5576c 100%); border-radius: 12px; padding: 1.2rem 1rem; color: #222; box-shadow: 0 2px 8px rgba(240,147,251,0.08);">
                    <div style="font-size: 1.1rem; font-weight: 600; color: #ad1457;">🌬️ Air Quality (AQI)</div>
                    <div style="font-size: 2.1rem; font-weight: 700; margin: 0.2rem 0;">45</div>
                    <div style="font-size: 1rem; color: #ad1457;">Good</div>
                </div>
            ''', unsafe_allow_html=True)

        # Add charts below the cards
        import plotly.graph_objects as go
        import pandas as pd
        import numpy as np
        from datetime import datetime, timedelta

        # Generate sample data for charts
        end_date = datetime.now()
        dates = pd.date_range(end=end_date, periods=30)
        energy = np.random.normal(1200, 100, size=30)
        water = np.random.normal(8_000_000, 500_000, size=30)
        aqi = np.random.normal(45, 8, size=30)

        chart_col1, chart_col2, chart_col3 = st.columns([1.2, 1.2, 1.2])
        with chart_col1:
            st.markdown('<div class="chart-container">', unsafe_allow_html=True)
            fig_energy = go.Figure()
            fig_energy.add_trace(go.Scatter(x=dates, y=energy, mode='lines+markers', name='Energy Consumption', line=dict(color='#43e97b')))
            fig_energy.update_layout(title="Energy Consumption Trend (Last 30 Days)", xaxis_title="Date", yaxis_title="MWh", height=350)
            st.plotly_chart(fig_energy, use_container_width=True)
            st.markdown('</div>', unsafe_allow_html=True)

        with chart_col2:
            st.markdown('<div class="chart-container">', unsafe_allow_html=True)
            fig_water = go.Figure()
            fig_water.add_trace(go.Bar(x=dates, y=water, name='Water Usage', marker_color='#f7971e'))
            fig_water.update_layout(title="Water Usage Trend (Last 30 Days)", xaxis_title="Date", yaxis_title="Gallons", height=350)
            st.plotly_chart(fig_water, use_container_width=True)
            st.markdown('</div>', unsafe_allow_html=True)

        with chart_col3:
            st.markdown('<div class="chart-container">', unsafe_allow_html=True)
            fig_aqi = go.Figure()
            fig_aqi.add_trace(go.Scatter(x=dates, y=aqi, mode='lines+markers', name='AQI', line=dict(color='#f093fb')))
            fig_aqi.update_layout(title="Air Quality Index (AQI) Over Time", xaxis_title="Date", yaxis_title="AQI", height=350)
            st.plotly_chart(fig_aqi, use_container_width=True)
            st.markdown('</div>', unsafe_allow_html=True)

        st.markdown("<div style='margin-top:2rem; color:#888; font-size:0.95rem;'>All data is for demonstration purposes only.</div>", unsafe_allow_html=True)
    elif selected == "Policy Search":
        render_document_uploader()
        st.divider()
        render_policy_search()
        st.divider()
        render_policy_summarizer()
    elif selected == "Chat":
        render_chat_assistant()
    elif selected == "Eco Tips":
        render_eco_tips()
    elif selected == "KPI Forecasting":
        render_kpi_forecasting()
    elif selected == "Anomaly Checker":
        render_anomaly_checker()
    elif selected == "Report Generator":
        render_report_generator()
    elif selected == "Feedback":
        render_feedback_form()

if __name__ == "__main__":
    main() 